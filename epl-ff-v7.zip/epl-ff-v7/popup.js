"use strict";
const _br = (typeof browser!=="undefined"&&browser.storage)?browser
           :(typeof chrome!=="undefined"&&chrome.storage)?chrome:null;
async function stGet(d){if(!_br)return d;try{return await _br.storage.sync.get(d);}catch(_){return d;}}
async function stSet(o){if(!_br)return;try{await _br.storage.sync.set(o);}catch(_){}}
async function getTab(){if(!_br)return null;try{const t=await _br.tabs.query({active:true,currentWindow:true});return t[0]||null;}catch(_){return null;}}
async function notifyTab(msg){const t=await getTab();if(t)_br.tabs.sendMessage(t.id,msg).catch(()=>{});}

// ── Colour schemes ────────────────────────────────────────────────────────
const SCHEMES = [
  { id:"auto",    name:"Auto",       email:"#2962ff", phone:"#00875a" },
  { id:"classic", name:"Classic",    email:"#0066cc", phone:"#007744" },
  { id:"vibrant", name:"Vibrant",    email:"#e91e63", phone:"#00bcd4" },
  { id:"warm",    name:"Warm",       email:"#e65100", phone:"#6a1fa0" },
  { id:"cool",    name:"Cool",       email:"#1565c0", phone:"#00838f" },
  { id:"dark",    name:"Dark (inv)", email:"#90caf9", phone:"#80cbc4" },
  { id:"hi",      name:"High cont.", email:"#000099", phone:"#005500" },
  { id:"pastel",  name:"Pastel",     email:"#7986cb", phone:"#4db6ac" },
  { id:"mono",    name:"Mono",       email:"#424242", phone:"#616161" },
];

const EMAIL_P = ["#2962ff","#7c3aed","#db2777","#ea580c","#0097a7","#374151"];
const PHONE_P = ["#00875a","#0097a7","#7c3aed","#b71c1c","#e65100","#1565c0"];

const DEFAULTS = {
  mailtoCustom:false, mailtoColor:"#2962ff",
  telCustom:false,    telColor:"#00875a",
  convertMode:"both", clickAction:"copy", copyWhat:"text",
  hoverTooltip:false, delaySeconds:0,
  colorScheme:"auto", schemeMode:"auto",
  searchOnly:false,   disabledHosts:[],
};
let state={...DEFAULTS};
let currentHost="",currentTabId=null;
const $=id=>document.getElementById(id);

// ── Hex validation ────────────────────────────────────────────────────────
function toHex(r){let s=r.trim();if(!s.startsWith("#"))s="#"+s;
  if(/^#[0-9a-fA-F]{3}$/.test(s))s="#"+s[1]+s[1]+s[2]+s[2]+s[3]+s[3];
  return/^#[0-9a-fA-F]{6}$/.test(s)?s.toLowerCase():null;}

// ── Flash ─────────────────────────────────────────────────────────────────
let saveTm=null;
function flash(){const m=$("saved-msg");m.classList.add("show");
  clearTimeout(saveTm);saveTm=setTimeout(()=>m.classList.remove("show"),1600);}

// ── Commit ────────────────────────────────────────────────────────────────
async function commit(skipNotify){
  const s={mailtoCustom:state.mailtoCustom,mailtoColor:state.mailtoColor,
           telCustom:state.telCustom,telColor:state.telColor,
           convertMode:state.convertMode,clickAction:state.clickAction,
           copyWhat:state.copyWhat,hoverTooltip:state.hoverTooltip,
           delaySeconds:state.delaySeconds,colorScheme:state.colorScheme,
           schemeMode:state.schemeMode,searchOnly:state.searchOnly,
           disabledHosts:state.disabledHosts};
  await stSet(s);
  if(!skipNotify)notifyTab({type:"EPL_SETTINGS_CHANGED",settings:state});
  flash();
}

// ── Page toggle ───────────────────────────────────────────────────────────
function isDisabled(){return(state.disabledHosts||[]).includes(currentHost);}
function syncPill(){
  const dis=isDisabled();
  const pill=$("page-pill");
  pill.classList.toggle("disabled",dis);
  $("pill-dot").style.background=dis?"#ff9090":"#6fff9e";
  $("pill-label").textContent=dis?"OFF":"ON";
}
async function togglePage(){
  if(!currentHost)return;
  const fresh=await stGet({disabledHosts:[]});
  const hosts=[...(fresh.disabledHosts||[])];
  const idx=hosts.indexOf(currentHost);
  if(idx>=0)hosts.splice(idx,1);else hosts.push(currentHost);
  state.disabledHosts=hosts;
  await stSet({disabledHosts:hosts});
  syncPill();flash();
  if(_br&&currentTabId!=null)_br.tabs.reload(currentTabId).catch(()=>{});
}
$("page-pill").addEventListener("click",togglePage);

// ── Segments ──────────────────────────────────────────────────────────────
function wireSeg(id,key){
  $(id).querySelectorAll(".seg-btn").forEach(b=>{
    b.addEventListener("click",()=>{
      $(id).querySelectorAll(".seg-btn").forEach(x=>x.classList.remove("active"));
      b.classList.add("active");state[key]=b.dataset.val;commit();
    });
  });
}
function setSeg(id,val){
  $(id).querySelectorAll(".seg-btn").forEach(b=>b.classList.toggle("active",b.dataset.val===val));}

// ── Delay input with stepper ──────────────────────────────────────────────
const DELAY_STEPS=[0,0.5,1,1.5,2,3,4,5,7,10,15,20,30];
function fmtDelay(v){return v===0?"0 sec":v+" sec";}
function snapDelay(v){
  // Find nearest valid step
  v=Math.max(0,Math.min(30,v));
  let best=DELAY_STEPS[0],bestD=Math.abs(v-DELAY_STEPS[0]);
  for(const s of DELAY_STEPS){const d=Math.abs(v-s);if(d<bestD){best=s;bestD=d;}}
  return best;
}
function setDelay(v){
  state.delaySeconds=v;
  $("delay-input").value=v===0?"0":String(v);
  $("delay-input").title="Delay: "+fmtDelay(v)+" after page loads";
}
$("delay-input").addEventListener("change",e=>{
  const v=snapDelay(parseFloat(e.target.value)||0);
  setDelay(v);commit();
});
$("delay-input").addEventListener("keydown",e=>{
  if(e.key==="Enter"){const v=snapDelay(parseFloat($("delay-input").value)||0);setDelay(v);commit();}
});
$("delay-up").addEventListener("click",()=>{
  const cur=state.delaySeconds,idx=DELAY_STEPS.indexOf(cur);
  const next=idx>=0&&idx<DELAY_STEPS.length-1?DELAY_STEPS[idx+1]:Math.min(30,cur+0.5);
  setDelay(next);commit();
});
$("delay-dn").addEventListener("click",()=>{
  const cur=state.delaySeconds,idx=DELAY_STEPS.indexOf(cur);
  const prev=idx>0?DELAY_STEPS[idx-1]:Math.max(0,cur-0.5);
  setDelay(snapDelay(prev));commit();
});

// ── Colour schemes ────────────────────────────────────────────────────────
function buildSchemes(){
  const grid=$("scheme-grid");
  SCHEMES.forEach(s=>{
    const card=document.createElement("div");
    card.className="scheme-card";card.dataset.id=s.id;
    card.title=s.name+" — email: "+s.email+" / phone: "+s.phone;
    card.innerHTML=`<div class="scheme-dots">
      <span class="scheme-dot" style="background:${s.email}"></span>
      <span class="scheme-dot" style="background:${s.phone}"></span>
    </div><div class="scheme-name">${s.name}</div>`;
    card.addEventListener("click",()=>{
      state.colorScheme=s.id;
      if(s.id!=="auto"){
        state.mailtoCustom=true;state.mailtoColor=s.email;
        state.telCustom=true;state.telColor=s.phone;
      } else {
        state.mailtoCustom=false;state.telCustom=false;
      }
      syncColor("email");syncColor("phone");syncSchemes();
      commit();
    });
    grid.appendChild(card);
  });
}
function syncSchemes(){
  $("scheme-grid").querySelectorAll(".scheme-card").forEach(c=>{
    c.classList.toggle("active",c.dataset.id===state.colorScheme);});
}

// ── Colours ───────────────────────────────────────────────────────────────
function syncColor(t){
  const isE=t==="email",custom=isE?state.mailtoCustom:state.telCustom,
        color=isE?state.mailtoColor:state.telColor;
  $(`${t}-page`).classList.toggle("active",!custom);
  $(`${t}-custom`).classList.toggle("active",custom);
  $(`${t}-pick`).style.display=custom?"flex":"none";
  $(`${t}-swatch`).style.background=color;
  $(`${t}-picker`).value=color;$(`${t}-hex`).value=color;
  $(`${t}-presets`).querySelectorAll(".preset").forEach(p=>
    p.classList.toggle("active",p.dataset.color===color));
}
function setColor(t,hex){
  if(t==="email")state.mailtoColor=hex;else state.telColor=hex;
  state.colorScheme="custom";syncColor(t);syncSchemes();}
function buildPresets(t,colors){
  colors.forEach(color=>{
    const b=document.createElement("button");
    b.className="preset";b.style.background=color;b.dataset.color=color;b.title=color;
    b.addEventListener("click",()=>{setColor(t,color);commit();});
    $(`${t}-presets`).appendChild(b);
  });
}
function wireColor(t){
  const isE=t==="email";
  $(`${t}-page`).addEventListener("click",()=>{
    if(isE)state.mailtoCustom=false;else state.telCustom=false;
    syncColor(t);commit();});
  $(`${t}-custom`).addEventListener("click",()=>{
    if(isE)state.mailtoCustom=true;else state.telCustom=true;
    syncColor(t);commit();});
  $(`${t}-picker`).addEventListener("input",e=>{setColor(t,e.target.value);commit();});
  const hex=$(`${t}-hex`);
  const ch=()=>{const v=toHex(hex.value);if(v){setColor(t,v);commit();}else syncColor(t);};
  hex.addEventListener("blur",ch);
  hex.addEventListener("keydown",e=>{if(e.key==="Enter")ch();});
  hex.addEventListener("input",()=>{
    const v=toHex(hex.value);
    if(v){$(`${t}-swatch`).style.background=v;
      $(`${t}-presets`).querySelectorAll(".preset")
        .forEach(p=>p.classList.toggle("active",p.dataset.color===v));}
  });
}

// ── Checkboxes ────────────────────────────────────────────────────────────
$("search-only").addEventListener("change",e=>{state.searchOnly=e.target.checked;commit();});
$("hover-tooltip").addEventListener("change",e=>{state.hoverTooltip=e.target.checked;commit();});

// ── Reset ─────────────────────────────────────────────────────────────────
$("reset-btn").addEventListener("click",()=>{
  state={...DEFAULTS,disabledHosts:state.disabledHosts};
  renderAll();commit();});

// ── Render all ────────────────────────────────────────────────────────────
function renderAll(){
  syncPill();
  setSeg("mode-seg",state.convertMode);
  setSeg("action-seg",state.clickAction);
  setSeg("copy-what-seg",state.copyWhat||"text");
  setSeg("scheme-mode-seg",state.schemeMode||"auto");
  $("search-only").checked=!!state.searchOnly;
  $("hover-tooltip").checked=!!state.hoverTooltip;
  syncColor("email");syncColor("phone");
  syncSchemes();
  setDelay(Math.max(0,Math.min(30,state.delaySeconds||0)));
}

// ── Boot ──────────────────────────────────────────────────────────────────
buildSchemes();
buildPresets("email",EMAIL_P);
buildPresets("phone",PHONE_P);
wireColor("email");wireColor("phone");
wireSeg("mode-seg","convertMode");
wireSeg("action-seg","clickAction");
wireSeg("copy-what-seg","copyWhat");
wireSeg("scheme-mode-seg","schemeMode");

// Open converter page in new tab
const converterBtn = document.getElementById('open-converter');
if (converterBtn) {
  converterBtn.addEventListener('click', () => {
    if (_br && _br.tabs) {
      _br.tabs.create({ url: _br.runtime.getURL('converter.html') });
      window.close();
    }
  });
}

getTab().then(tab=>{
  if(!tab)return;
  currentTabId=tab.id;
  if(tab.url){try{currentHost=new URL(tab.url).hostname;$("page-host").textContent=currentHost||"settings";}catch(_){$("page-host").textContent="settings";}}
  stGet(DEFAULTS).then(stored=>{state={...DEFAULTS,...stored};renderAll();});
});
