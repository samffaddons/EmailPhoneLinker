/**
 * background.js — Email & Phone Linker v3.1
 * Handles ONLY the keyboard shortcut toggle.
 * Popup handles its own storage writes and tab reloads directly.
 */
"use strict";

const DEFAULTS = {
  mailtoCustom:false, mailtoColor:"#4a9eff",
  telCustom:false,    telColor:"#3dd68c",
  convertMode:"both", clickAction:"copy",
  copyWhat:"text",
  searchOnly:false,   delaySeconds:0,
  disabledHosts:[],
};

browser.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") browser.storage.sync.set(DEFAULTS);
});

// Hotkey: read current state, toggle, save, reload — all in one atomic operation.
// The popup does NOT send EPL_TOGGLE_HOST here — it handles toggles itself.
browser.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-conversion") return;
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) return;
  try {
    const host = new URL(tab.url).hostname;
    if (!host) return;
    const { disabledHosts = [] } = await browser.storage.sync.get({ disabledHosts: [] });
    const idx = disabledHosts.indexOf(host);
    if (idx >= 0) disabledHosts.splice(idx, 1);
    else disabledHosts.push(host);
    await browser.storage.sync.set({ disabledHosts });
    browser.tabs.reload(tab.id);
  } catch (_) {}
});
