/**
 * Email & Phone Linker — Firefox v3.2.1
 * New: hover tooltip, contrast-safe colouring, bigger toast, delay input,
 *      hover preview, all world phone formats (3+3+4, dot/slash delimiters).
 */
(function () {
  "use strict";

  if (window.__eplDone) return;
  window.__eplDone = true;

  const _B = (typeof browser !== "undefined" && browser && browser.storage) ? browser
           : (typeof chrome  !== "undefined" && chrome  && chrome.storage)  ? chrome : null;

  async function stGet(def) {
    if (!_B) return def;
    try { return await _B.storage.sync.get(def); } catch(_){} return def;
  }
  function onMsg(fn) {
    if (!_B) return;
    try { _B.runtime.onMessage.addListener(fn); } catch(_){}
  }

  // ── Search engine hosts ───────────────────────────────────────────────────
  const SEARCH_HOSTS = new Set([
    "www.google.com","google.com","google.co.in","google.co.uk","google.ca",
    "www.bing.com","bing.com","search.yahoo.com","yahoo.com",
    "duckduckgo.com","www.duckduckgo.com","yandex.com","yandex.ru","www.yandex.com",
    "www.baidu.com","baidu.com","search.brave.com","www.ecosia.org","www.startpage.com",
  ]);
  const currentHost    = location.hostname;
  const isSearchEngine = SEARCH_HOSTS.has(currentHost);

  // ── Defaults ─────────────────────────────────────────────────────────────
  const DEFAULTS = {
    mailtoCustom:false, mailtoColor:"#4a9eff",
    telCustom:false,    telColor:"#3dd68c",
    convertMode:"both", clickAction:"copy", copyWhat:"text",
    hoverTooltip:false, delaySeconds:0.5,
    colorScheme:"auto",
    searchOnly:false,   disabledHosts:[],
  };
  let cfg = { ...DEFAULTS };

  // ── Patterns ──────────────────────────────────────────────────────────────
  const EMAIL_RE =
    /(?<![=\/"'@\w])(?<email>[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/g;

  // Expanded: spaces, hyphens, dots, slashes — covers all world formats
  const PHONE_RE =
    /(?<![+\d(])(?<phone>(?:\+\d{1,3}[\s\-./]?)?(?:\(0?\d{1,4}\)[\s\-./]?)?\d[\d\s\-./]{4,}\d)(?![\d\-])/g;

  const VANITY_RE =
    /(?<![+\d(A-Za-z])(?<vanity>(?:\+\d{1,3}[\s\-.]?)?(?:\(\d{1,4}\)[\s\-.]|\d{1,4}[\-.])(?:[\dA-Za-z][\dA-Za-z\-.]*)*)(?![+\dA-Za-z\-.])/g;

  // ── Validation ────────────────────────────────────────────────────────────
  function stripCC(d) {
    const l = d.length;
    if (l === 11 && d[0] === "1") return d.slice(1);
    if (l === 12) return d.slice(2);
    if (l === 13) return d.slice(3);
    return d;
  }
  function isValidPhone(str) {
    if (!/\d{2}/.test(str)) return false;
    if (/^\d{5}-\d{4}$/.test(str.trim())) return false;
    const digits = (str.match(/\d/g) || []).join("");
    const sub = stripCC(digits);
    if (sub.length < 7 || sub.length > 12) return false;
    if (sub.length < 10 && /^[2-9]\d{2}\d/.test(sub)) return false;
    return true;
  }
  const KEYPAD = {A:2,B:2,C:2,D:3,E:3,F:3,G:4,H:4,I:4,J:5,K:5,L:5,
                  M:6,N:6,O:6,P:7,Q:7,R:7,S:7,T:8,U:8,V:8,W:9,X:9,Y:9,Z:9};
  const vDigits = s => s.toUpperCase().replace(/[A-Z]/g, c => KEYPAD[c] ?? c);
  const vHref   = s => "tel:" + (d => d.startsWith("+") ? d : "+" + d)
                         (vDigits(s).replace(/[\s\-.()/[\]]/g,""));
  function vSubDigits(s) { return stripCC(vDigits(s).replace(/[^\d]/g,"")); }
  function isValidVanity(str) {
    if (!/[A-Za-z]/.test(str)) return false;
    const sub = vSubDigits(str);
    if (sub.length < 7 || sub.length > 12) return false;
    const fi = str.search(/[A-Za-z]/);
    if ((str.slice(0,fi).match(/\d/g)||[]).length < 3) return false;
    const sd = str.replace(/^\+?1[\s\-.]/, "").replace(/[^\dA-Za-z]/g,"");
    const sdDig = vDigits(sd).replace(/[^\d]/g,"");
    if (/^[2-9]\d{2}/.test(sdDig) && sdDig.length < 10) return false;
    return true;
  }

  function norm(s) {
    return s
      .replace(/[\u00A0\u202F\u2007\u2009\u200A\u2060]/g," ")
      .replace(/[\u2010\u2011\u2012\u2013\u2014\u2015\uFE58\uFE63\uFF0D]/g,"-");
  }

  // ── Colour contrast helper ────────────────────────────────────────────────
  // Ensures the link colour is visible against its background.
  // If contrast < 3.0 (WCAG AA for large text), picks a safe alternative.
  function parseRgb(s) {
    if (!s) return null;
    const m = s.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    return m ? [+m[1],+m[2],+m[3]] : null;
  }
  function hexToRgb(h) {
    if (!h || h.length < 7) return null;
    return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
  }
  function rgbToHex([r,g,b]) {
    return "#" + [r,g,b].map(v => Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
  }
  function luminance([r,g,b]) {
    return [r,g,b].reduce((acc,v,i) => {
      v /= 255; v = v <= 0.03928 ? v/12.92 : Math.pow((v+0.055)/1.055,2.4);
      return acc + v * [0.2126,0.7152,0.0722][i];
    }, 0);
  }
  function contrastRatio(c1, c2) {
    const l1 = luminance(c1), l2 = luminance(c2);
    return (Math.max(l1,l2)+0.05) / (Math.min(l1,l2)+0.05);
  }
  function safeColor(fgHex, bgEl) {
    // Auto mode: check contrast and adjust if needed
    if ((cfg.colorScheme || "auto") !== "auto") return fgHex;
    if (!bgEl) return fgHex;
    const bgStyle = getComputedStyle(bgEl).backgroundColor;
    const bgRgb   = parseRgb(bgStyle);
    if (!bgRgb) return fgHex;
    const fgRgb = hexToRgb(fgHex);
    if (!fgRgb) return fgHex;
    if (contrastRatio(fgRgb, bgRgb) >= 3.0) return fgHex;
    // Try darkening the colour
    const darkened = fgRgb.map(v => Math.round(v * 0.45));
    if (contrastRatio(darkened, bgRgb) >= 3.0) return rgbToHex(darkened);
    // Try pure dark alternatives
    const fallbacks = [[0,80,200],[0,120,60],[180,0,0],[80,0,160],[0,0,0],[255,255,255]];
    for (const c of fallbacks) if (contrastRatio(c, bgRgb) >= 3.0) return rgbToHex(c);
    return fgHex;
  }

  // ── Settings / colour ─────────────────────────────────────────────────────
  let pageColor = null;
  function getPageColor() {
    if (pageColor) return pageColor;
    for (const a of document.querySelectorAll("a[href]")) {
      const c = getComputedStyle(a).color;
      if (c && c !== "rgba(0, 0, 0, 0)" && c !== "transparent")
        return (pageColor = c);
    }
    return (pageColor = "blue");
  }
  function colorFor(type) {
    if (type === "mailto" && cfg.mailtoCustom) return cfg.mailtoColor;
    if (type === "tel"    && cfg.telCustom)    return cfg.telColor;
    return getPageColor();
  }
  function styleLink(a) {
    const raw    = colorFor(a.dataset.eplType || "mailto");
    const parent = a.parentElement;
    const color  = (cfg.colorScheme || "auto") === "auto" ? safeColor(raw, parent) : raw;
    a.style.color          = color;
    a.style.textDecoration = "underline";
  }
  function recolor() {
    pageColor = null;
    document.querySelectorAll("a[data-epl='1']").forEach(styleLink);
  }

  // ── Toast (bigger, more visible) ─────────────────────────────────────────
  let _toast = null, _toastTm = null;
  function showToast(msg, isError) {
    if (!_toast || !_toast.isConnected) {
      _toast = document.createElement("div");
      Object.assign(_toast.style, {
        position:"fixed", bottom:"28px", left:"50%",
        transform:"translateX(-50%) translateY(16px)",
        background:"#1e2433", color:"#ffffff",
        border:"2px solid #3a4a70", borderRadius:"12px",
        padding:"12px 24px", fontSize:"16px", fontWeight:"600",
        fontFamily:"system-ui,-apple-system,sans-serif", lineHeight:"1.4",
        boxShadow:"0 6px 32px rgba(0,0,0,.6)", zIndex:"2147483647",
        pointerEvents:"none", opacity:"0",
        transition:"opacity 200ms ease,transform 200ms ease",
        whiteSpace:"nowrap", maxWidth:"90vw",
        letterSpacing:".01em",
      });
      document.documentElement.appendChild(_toast);
    }
    _toast.textContent = msg;
    _toast.style.borderColor = isError ? "#f87171" : "#4ade80";
    _toast.style.color       = "#ffffff";
    _toast.offsetHeight;
    _toast.style.opacity   = "1";
    _toast.style.transform = "translateX(-50%) translateY(0)";
    clearTimeout(_toastTm);
    _toastTm = setTimeout(() => {
      _toast.style.opacity   = "0";
      _toast.style.transform = "translateX(-50%) translateY(16px)";
    }, 2800);
  }

  // ── Hover tooltip ─────────────────────────────────────────────────────────
  let _tip = null, _tipTm = null;
  function showTip(text, anchorEl) {
    if (!cfg.hoverTooltip) return;
    hideTip();
    _tip = document.createElement("div");
    Object.assign(_tip.style, {
      position:"fixed", zIndex:"2147483646",
      background:"#1e2433", color:"#e8eeff",
      border:"1px solid #3a4a70", borderRadius:"7px",
      padding:"6px 12px", fontSize:"13px",
      fontFamily:"system-ui,-apple-system,sans-serif",
      boxShadow:"0 3px 14px rgba(0,0,0,.5)",
      pointerEvents:"none", whiteSpace:"nowrap",
    });
    _tip.textContent = text;
    document.documentElement.appendChild(_tip);
    // Position above the link
    const r = anchorEl.getBoundingClientRect();
    const tipW = 200; // estimate before rendering
    const left = Math.max(8, Math.min(r.left + r.width/2 - tipW/2, window.innerWidth - tipW - 8));
    _tip.style.left   = left + "px";
    _tip.style.top    = Math.max(8, r.top - 36) + "px";
    _tip.style.opacity = "0";
    _tip.style.transition = "opacity 120ms";
    requestAnimationFrame(() => { if (_tip) _tip.style.opacity = "1"; });
  }
  function hideTip() {
    if (_tip) { _tip.remove(); _tip = null; }
    clearTimeout(_tipTm);
  }

  // ── Hover listener ────────────────────────────────────────────────────────
  document.addEventListener("mouseover", e => {
    if (!cfg.hoverTooltip) return;
    const a = e.target.closest("a[data-epl-type='tel'],a[href^='tel:'],a[href^='TEL:']");
    if (!a) { hideTip(); return; }
    clearTimeout(_tipTm);
    const href    = a.getAttribute("href") || "";
    const eplCopy = a.dataset.eplCopy || href.replace(/^tel:/i,"").trim();
    if (!eplCopy) return;
    const delay = cfg.delaySeconds > 0 ? `  ⏱ ${cfg.delaySeconds}s delay` : "";
    const label = (cfg.copyWhat === "url")
      ? `📋 Copy: ${eplCopy}`
      : `📋 Copy: ${a.dataset.eplText || eplCopy}`;
    showTip(label, a);
  }, true);
  document.addEventListener("mouseout", e => {
    const a = e.target.closest("a[data-epl-type='tel'],a[href^='tel:'],a[href^='TEL:']");
    if (a) _tipTm = setTimeout(hideTip, 200);
  }, true);

  // ── Action popup ─────────────────────────────────────────────────────────
  let _popup = null;
  function showActionPopup(num, href) {
    if (_popup) _popup.remove();
    _popup = document.createElement("div");
    Object.assign(_popup.style, {
      position:"fixed", bottom:"28px", left:"50%",
      transform:"translateX(-50%)",
      background:"#1e2433", color:"#e8eeff",
      border:"2px solid #3a4a70", borderRadius:"12px",
      padding:"14px 18px", fontSize:"15px",
      fontFamily:"system-ui,-apple-system,sans-serif",
      boxShadow:"0 6px 28px rgba(0,0,0,.65)", zIndex:"2147483647",
      display:"flex", gap:"10px", alignItems:"center",
    });
    const label = document.createElement("span");
    label.textContent = num;
    Object.assign(label.style,{
      marginRight:"4px",opacity:".8",fontSize:"14px",
      maxWidth:"200px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"
    });
    const mk = (text, bg, fg, cb) => {
      const b = document.createElement("button");
      b.textContent = text;
      Object.assign(b.style,{
        background:bg, border:`1px solid ${fg}44`, borderRadius:"7px",
        color:fg, fontSize:"13px", fontWeight:"600",
        padding:"6px 14px", cursor:"pointer", fontFamily:"inherit",
      });
      b.onclick = cb;
      return b;
    };
    const closeBtn = document.createElement("button");
    closeBtn.textContent = "✕";
    Object.assign(closeBtn.style,{
      background:"none",border:"none",color:"#8090b0",
      fontSize:"16px",cursor:"pointer",padding:"0 2px",marginLeft:"4px"
    });
    closeBtn.onclick = () => _popup.remove();
    _popup.append(
      label,
      mk("📋 Copy","#1e3355","#7ab8ff",() => { doCopy(num, _popup); _popup.remove(); }),
      mk("📲 Dial","#1a3322","#4ade80",() => { window.location.href = href; _popup.remove(); }),
      closeBtn
    );
    document.documentElement.appendChild(_popup);
    setTimeout(() => { if (_popup) _popup.remove(); }, 7000);
  }

  // ── Copy ─────────────────────────────────────────────────────────────────
  // Works in all contexts: normal pages, modal overlays, focus-trapped dialogs,
  // shadow DOM, <dialog> elements.
  //
  // Order of attempts:
  //  1. navigator.clipboard.writeText() — PREFERRED.
  //     Called inside a click (user gesture), so it is always permitted by the
  //     browser regardless of which element has visual focus. Modal focus traps
  //     cannot interfere because this API does not involve DOM focus at all.
  //  2. execCommand fallback — for browsers/contexts where Clipboard API is
  //     unavailable. The textarea is appended INSIDE the modal/active container
  //     (not document.documentElement) so focus-trap scripts don't steal focus
  //     before execCommand fires.

  // Find the best container to append a helper element into.
  // Walks up from 'fromEl' looking for a shadow root host, <dialog>,
  // or role="dialog" element; falls back to document.documentElement.
  function _copyContainer(fromEl) {
    if (!fromEl) return document.documentElement;
    let el = fromEl;
    while (el && el !== document.documentElement) {
      // Inside a shadow DOM — use the shadow root's host's parent
      if (el.shadowRoot) return el;
      const tag  = el.tagName && el.tagName.toUpperCase();
      const role = (el.getAttribute && el.getAttribute("role")) || "";
      // <dialog> or role="dialog" / role="alertdialog" — modal container found
      if (tag === "DIALOG" || role === "dialog" || role === "alertdialog") return el;
      // Common modal patterns: elements with very high z-index or modal-like classes
      if (el.style) {
        const z = parseInt(getComputedStyle(el).zIndex, 10);
        if (z > 100 && getComputedStyle(el).position !== "static") {
          // Likely a modal overlay — use it as container
          return el;
        }
      }
      el = el.parentElement;
    }
    return document.documentElement;
  }

  function _execCopy(text, container) {
    try {
      const ta = document.createElement("textarea");
      Object.assign(ta.style, {
        position: "fixed", top: "0", left: "0",
        width: "2px", height: "2px", opacity: "0.001",
        pointerEvents: "none", zIndex: "2147483647",
      });
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.setAttribute("aria-hidden", "true");
      // Append inside the modal/active container, not documentElement
      (container || document.documentElement).appendChild(ta);
      ta.focus({ preventScroll: true });
      ta.select();
      const success = document.execCommand("copy");
      ta.remove();
      return success;
    } catch (_) { return false; }
  }

  function doCopy(text, sourceEl) {
    const onOk   = () => showToast("✓  Copied  " + text, false);
    const onFail = () => showToast("✗  Could not copy", true);

    // 1. Clipboard API — works during user gesture regardless of modal focus
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(onOk).catch(() => {
        // 2. execCommand fallback — append into the same container as the link
        const container = _copyContainer(sourceEl || document.activeElement);
        if (_execCopy(text, container)) onOk();
        else onFail();
      });
      return;
    }

    // No Clipboard API — use execCommand directly
    const container = _copyContainer(sourceEl || document.activeElement);
    if (_execCopy(text, container)) onOk();
    else onFail();
  }

  // ── Click handler ─────────────────────────────────────────────────────────
  document.addEventListener("click", e => {
    const a = e.target.closest("a[data-epl-type='tel'],a[href^='tel:'],a[href^='TEL:']");
    if (!a) return;
    hideTip();
    const href    = a.getAttribute("href") || "";
    const eplText = a.dataset.eplText || "";
    const eplCopy = a.dataset.eplCopy || "";
    const rawTxt  = (a.textContent || "").trim();
    const wantUrl = (cfg.copyWhat || "text") === "url";
    let num;
    if (wantUrl) {
      num = eplCopy || href.replace(/^tel:/i,"").trim() || null;
    } else {
      const vis = eplText || (rawTxt && /\d/.test(rawTxt) ? rawTxt : "");
      num = (vis || null) || eplCopy || href.replace(/^tel:/i,"").trim() || null;
    }
    if (!num) return;
    e.preventDefault(); e.stopPropagation();
    const action = cfg.clickAction || "copy";
    if (action === "open")       window.location.href = href || ("tel:" + num);
    else if (action === "popup") showActionPopup(num, href || ("tel:" + num));
    else                         doCopy(num, a);
  }, true);

  // ── Element classification ─────────────────────────────────────────────────
  const SKIP_TAGS  = new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","SELECT","BUTTON",
    "CODE","PRE","KBD","SAMP","VAR","INPUT","OPTION","HEAD","META","TITLE","LINK",
    "OBJECT","EMBED","CANVAS","SVG","MATH","TEMPLATE"]);
  const BLOCK_TAGS = new Set(["DIV","P","LI","TD","TH","H1","H2","H3","H4","H5","H6",
    "ARTICLE","SECTION","BLOCKQUOTE","HEADER","FOOTER","MAIN","ASIDE","NAV","FIGURE",
    "FIGCAPTION","DT","DD","DETAILS","SUMMARY","ADDRESS","FORM","FIELDSET","TABLE",
    "TR","TBODY","THEAD","TFOOT","UL","OL","DL"]);
  const DONE_ATTR = "data-epl-s";

  // ── Inline run collection ─────────────────────────────────────────────────
  function collectRuns(root) {
    const runs = []; let cur = [];
    const flush = () => { if (cur.length) { runs.push(cur); cur = []; } };
    function walk(el) {
      for (const child of el.childNodes) {
        if (child.nodeType === Node.TEXT_NODE) {
          if (child.nodeValue) cur.push({ node:child, text:child.nodeValue });
        } else if (child.nodeType === Node.ELEMENT_NODE) {
          const tag = child.tagName.toUpperCase();
          if (SKIP_TAGS.has(tag)) continue;
          if (tag === "A") {
            const href = (child.getAttribute("href")||"").toLowerCase();
            if (href.startsWith("tel:")||href.startsWith("mailto:")
                ||(child.dataset&&child.dataset.epl)) { flush(); continue; }
            walk(child); continue;
          }
          if (child.hidden||child.getAttribute("aria-hidden")==="true") continue;
          if (BLOCK_TAGS.has(tag)) flush(); else walk(child);
        }
      }
    }
    walk(root); flush(); return runs;
  }

  // ── Find matches ──────────────────────────────────────────────────────────
  function findMatches(text) {
    const n      = norm(text);
    const hasAt  = text.includes("@");
    const hasDig = /(?:\d[\s\-./]*){7}/.test(n);
    const hasVan = /\d{3}[\-.](?:[\dA-Za-z][\-.])*[A-Za-z]{2}/.test(n);
    if (!hasAt && !hasDig && !hasVan) return [];
    const mode = cfg.convertMode || "both";
    const out  = [];
    if (hasAt && mode !== "tel") {
      EMAIL_RE.lastIndex = 0;
      for (let m; (m=EMAIL_RE.exec(text));)
        out.push({start:m.index,end:m.index+m.groups.email.length,
                  display:m.groups.email,type:"email"});
    }
    if (hasDig && mode !== "email") {
      PHONE_RE.lastIndex = 0;
      for (let m; (m=PHONE_RE.exec(n));) {
        if (!isValidPhone(m.groups.phone)) continue;
        out.push({start:m.index,end:m.index+m.groups.phone.length,
                  display:text.slice(m.index,m.index+m.groups.phone.length),
                  normText:m.groups.phone,type:"tel"});
      }
    }
    if (hasVan && mode !== "email") {
      VANITY_RE.lastIndex = 0;
      for (let m; (m=VANITY_RE.exec(n));) {
        let v=m.groups.vanity, end=m.index+v.length;
        if (vSubDigits(v).length < 10 && end < n.length && n[end]===" ") {
          const ext=n.slice(end+1).match(/^[A-Za-z0-9]{1,6}/);
          if (ext){const cand=v+" "+ext[0];if(vSubDigits(cand).length>=7){v=cand;end+=1+ext[0].length;VANITY_RE.lastIndex=end;}}
        }
        if (!isValidVanity(v)) continue;
        out.push({start:m.index,end:m.index+v.length,
                  display:vDigits(v),orig:text.slice(m.index,m.index+v.length),type:"vanity"});
      }
    }
    out.sort((a,b)=>a.start-b.start);
    const deduped=[]; let last=0;
    for(const m of out) if(m.start>=last){deduped.push(m);last=m.end;}
    return deduped;
  }

  // ── Create link ───────────────────────────────────────────────────────────
  function mkLink(match) {
    const a = document.createElement("a");
    if (match.type === "email") {
      a.textContent = match.display;
      a.href = "mailto:" + match.display.trim();
      a.dataset.eplType = "mailto";
    } else if (match.type === "tel") {
      a.textContent = match.display;
      const n2 = match.normText || norm(match.display);
      const href = "tel:" + (n2.trimStart().startsWith("+")
        ? n2.replace(/[\s\-.()/[\]]/g,"")
        : "+" + n2.replace(/[\s\-.()/[\]]/g,""));
      a.href = href;
      a.dataset.eplText = match.display;
      a.dataset.eplCopy = href.replace(/^tel:/,"");
      a.dataset.eplType = "tel";
    } else {
      a.textContent = match.display;
      a.title = match.orig || match.display;
      const h = vHref(match.orig || match.display);
      a.href  = h;
      a.dataset.eplText = match.display;
      a.dataset.eplCopy = h.replace(/^tel:/,"");
      a.dataset.eplType = "tel";
    }
    a.dataset.epl = "1";
    styleLink(a);
    return a;
  }

  // ── Apply matches ─────────────────────────────────────────────────────────
  function applyRun(run, matches) {
    if (!matches.length) return;
    let combined=""; const map=[];
    for(const seg of run){map.push({seg,start:combined.length,end:combined.length+seg.text.length});combined+=seg.text;}
    for(const {seg,start:ss,end:se} of map){
      const over=matches.filter(m=>m.end>ss&&m.start<se);
      if(!over.length)continue;
      const frag=document.createDocumentFragment();
      let pos=ss;
      for(const match of over){
        const os=Math.max(match.start,ss),oe=Math.min(match.end,se);
        if(os>pos)frag.appendChild(document.createTextNode(combined.slice(pos,os)));
        if(match.start>=ss&&match.start<se)frag.appendChild(mkLink(match));
        pos=oe;
      }
      if(pos<se)frag.appendChild(document.createTextNode(combined.slice(pos,se)));
      if(!seg.node.parentNode)continue;
      if(frag.childNodes.length)seg.node.parentNode.replaceChild(frag,seg.node);
      else seg.node.parentNode.removeChild(seg.node);
    }
  }

  // ── Scan ──────────────────────────────────────────────────────────────────
  function scanBlock(block) {
    if(block.hasAttribute(DONE_ATTR))return;
    block.setAttribute(DONE_ATTR,"1");
    for(const run of collectRuns(block))
      applyRun(run,findMatches(run.map(s=>s.text).join("")));
  }
  function collectBlocks(root) {
    if(!root||root.nodeType!==Node.ELEMENT_NODE)return[];
    const blocks=[];
    const tag=root.tagName&&root.tagName.toUpperCase();
    if(tag&&BLOCK_TAGS.has(tag)&&!root.hasAttribute(DONE_ATTR))blocks.push(root);
    const walker=(root.ownerDocument||document).createTreeWalker(
      root,NodeFilter.SHOW_ELEMENT,{
        acceptNode(n){
          const t=n.tagName.toUpperCase();
          if(SKIP_TAGS.has(t)||n.hidden)return NodeFilter.FILTER_REJECT;
          if(n.hasAttribute(DONE_ATTR))return NodeFilter.FILTER_REJECT;
          if(BLOCK_TAGS.has(t))return NodeFilter.FILTER_ACCEPT;
          return NodeFilter.FILTER_SKIP;
        }
      },false);
    let cur;while((cur=walker.nextNode()))blocks.push(cur);
    return blocks;
  }

  // ── Batch processor ───────────────────────────────────────────────────────
  const BATCH=20,IDLE_TO=3000;
  function processBatch(blocks,idx){
    if(idx>=blocks.length||document.hidden)return;
    scheduleIdle(dl=>{
      let i=idx;
      while(i<blocks.length){
        if(dl&&dl.timeRemaining()<2)break;
        if(i-idx>=BATCH)break;
        try{scanBlock(blocks[i]);}catch(_){}
        i++;
      }
      if(i<blocks.length)scheduleIdle(()=>processBatch(blocks,i));
    });
  }
  function scheduleIdle(fn){
    if(typeof requestIdleCallback!=="undefined")
      requestIdleCallback(fn,{timeout:IDLE_TO});
    else setTimeout(()=>fn({timeRemaining:()=>50}),16);
  }

  // ── MutationObserver ─────────────────────────────────────────────────────
  const MAX_PEND=25,DEBOUNCE=800;
  let mutTm=null;const pend=new Set();
  function onMuts(muts){
    if(document.hidden)return;
    for(const mut of muts){
      if(pend.size>=MAX_PEND)break;
      for(const node of mut.addedNodes){
        if(node.nodeType!==Node.ELEMENT_NODE)continue;
        const tag=node.tagName&&node.tagName.toUpperCase();
        if(SKIP_TAGS.has(tag))continue;
        if(!node.textContent||node.textContent.trim().length<7)continue;
        if(node.dataset&&node.dataset.epl)continue;
        if(pend.size<MAX_PEND)pend.add(node);
      }
    }
    clearTimeout(mutTm);mutTm=setTimeout(flushPend,DEBOUNCE);
  }
  function flushPend(){
    if(document.hidden)return;
    const nodes=Array.from(pend);pend.clear();
    const blocks=[];
    for(const node of nodes)
      for(const b of collectBlocks(node))
        if(!b.hasAttribute(DONE_ATTR))blocks.push(b);
    if(blocks.length)processBatch(blocks,0);
  }
  let obs=null;
  function startObs(){
    obs=new MutationObserver(onMuts);
    obs.observe(document.body||document.documentElement,{childList:true,subtree:true});
  }

  // ── Visibility ────────────────────────────────────────────────────────────
  document.addEventListener("visibilitychange",()=>{
    if(document.visibilityState==="visible"){
      pageColor=null;
      document.querySelectorAll("a[data-epl='1']").forEach(styleLink);
    }
  });

  // ── Settings update ───────────────────────────────────────────────────────
  onMsg(msg=>{
    if(!msg)return;
    if(msg.type==="EPL_SETTINGS_CHANGED"){
      Object.assign(cfg,msg.settings||msg);
      recolor();
    }
  });

  // ── Entry point ───────────────────────────────────────────────────────────
  async function init(){
    if(document.hidden){
      document.addEventListener("visibilitychange",function onVis(){
        if(document.visibilityState!=="visible")return;
        document.removeEventListener("visibilitychange",onVis);
        init();
      });
      return;
    }
    const stored=await stGet(DEFAULTS);
    Object.assign(cfg,stored);
    if((cfg.disabledHosts||[]).includes(currentHost))return;
    if(cfg.searchOnly&&!isSearchEngine)return;
    const delay=Math.max(0,Math.min(30,cfg.delaySeconds||0))*1000;
    const run=()=>{
      pageColor=null;
      scheduleIdle(()=>{
        const blocks=collectBlocks(document.body||document.documentElement);
        processBatch(blocks,0);
        startObs();
      });
    };
    if(delay>0)setTimeout(run,delay);else run();
  }

  if(document.readyState==="complete")init();
  else window.addEventListener("load",init,{once:true});

})();
